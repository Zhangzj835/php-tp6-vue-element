<?php
declare (strict_types=1);

namespace app\subscribe;
/**
 * 用户相关事件订阅
 * Class User
 * @package app\subscribe
 * @author 2066362155@qq.com
 */
class User
{

}
