<?php
declare (strict_types=1);
namespace app\util;

/**
 * 数据处理
 * Class TimeUtil
 * @package app\util
 */
class TimeUtil
{

    /**
     * 获取当前日期
     */
    public function getCurrentDate() {
        return '';
    }


}