<?php
declare (strict_types=1);
namespace app\controller;

use app\BaseController;

/**
 * api接口基类
 * Class ApiController
 * @package app\controller
 * @author  2066362155@qq.com
 */
class ApiController extends BaseController
{
    // 初始化
    protected function initialize()
    {

    }

}
