<template>
  <div class="app-container">
    test / demo
  </div>
</template>

<script>

export default {
  name: 'demo',
  components: { },  
  filters: {},
  data() {
    return {
      
    }
  },
  watch: {
    
  },
  created() {
    this.init()
  },
  methods: {
    init() {
      
    }
    
  }
}
</script>
