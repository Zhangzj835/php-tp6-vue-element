<template>
  <div class="app-container">
    test / index
  </div>
</template>

<script>
export default {
  name: 'index',
  components: { },  
  filters: {},
  data() {
    return {
      
    }
  },
  watch: {
    
  },
  created() {
    this.init()
  },
  methods: {
    init() {
      
    }
    
  }
}
</script>
